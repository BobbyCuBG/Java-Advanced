package _06_DefiningClasses.Exercise._09_CatLady;

public class StreetExtraordinaire {
    private String name;
    private double decibelsOfMeows;

    public StreetExtraordinaire(String name, double decibelsOfMeows) {
        this.name = name;
        this.decibelsOfMeows = decibelsOfMeows;
    }

    public String getName() {
        return name;
    }

    public double getDecibelsOfMeows() {
        return decibelsOfMeows;
    }
}

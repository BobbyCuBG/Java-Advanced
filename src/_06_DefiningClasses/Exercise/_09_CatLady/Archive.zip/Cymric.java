package _06_DefiningClasses.Exercise._09_CatLady;

public class Cymric {
    private String name;
    private double furLength;

    public Cymric(String name, double furLength) {
        this.name = name;
        this.furLength = furLength;
    }

    public String getName() {
        return name;
    }

    public double getFurLength() {
        return furLength;
    }
}

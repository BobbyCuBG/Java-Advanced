package _06_DefiningClasses.Exercise._09_CatLady;

public class Siamese {
    private String name;
    private double earSize;

    public Siamese(String name, double earSize) {
        this.name = name;
        this.earSize = earSize;
    }

    public String getName() {
        return name;
    }

    public double getEarSize() {
        return earSize;
    }
}

package _07_Generics.Exercise._07_CustomList;

public class Sorter {
}
